import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class MapReader {
    public static char[][][] readMapFile(String filename)
            throws FileNotFoundException,
                   IncorrectMapFormatException,
                   IllegalMapCharacterException,
                   IncompleteMapException {

        File file = resolveFile(filename);
        Scanner scanner = new Scanner(file);

        int[] dims = readHeader(scanner, filename);
        int M = dims[0];
        int N = dims[1];
        int R = dims[2];

        char[][][] mazes = new char[R][M][N];

        for (int r = 0; r < R; r++) {
            for (int row = 0; row < M; row++) {

                String line = nextMeaningfulLine(scanner);

                if (line == null) {
                    scanner.close();
                    throw new IncompleteMapException(
                        "Ran out of input in maze " + r + " at row " + row
                        + ". Expected " + M + " rows per maze.");
                }

                if (line.length() < N) {
                    scanner.close();
                    throw new IncompleteMapException(
                        "Maze " + r + ", row " + row + " has " + line.length()
                        + " character(s) but needs " + N + ".");
                }

                for (int col = 0; col < N; col++) {
                    char ch = line.charAt(col);
                    if (!isValidChar(ch)) {
                        scanner.close();
                        throw new IllegalMapCharacterException(
                            "Illegal character '" + ch + "' at maze " + r
                            + ", row " + row + ", col " + col + ".");
                    }
                    mazes[r][row][col] = ch;
                }
            }
        }

        scanner.close();
        return mazes;
    }

    
    public static char[][][] readCoordinateFile(String filename)
            throws FileNotFoundException,
                   IncorrectMapFormatException,
                   IllegalMapCharacterException,
                   IncompleteMapException {

        File file = resolveFile(filename);
        Scanner scanner = new Scanner(file);

        int[] dims = readHeader(scanner, filename);
        int M = dims[0];
        int N = dims[1];
        int R = dims[2];

        char[][][] mazes = new char[R][M][N];
        for (int r = 0; r < R; r++)
            for (int row = 0; row < M; row++)
                for (int col = 0; col < N; col++)
                    mazes[r][row][col] = '.';

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine().trim();
            if (line.isEmpty() || line.startsWith("//")) continue;

            String[] tokens = line.split("\\s+");
            if (tokens.length < 4) continue;

            char ch = tokens[0].charAt(0);

            if (!isValidChar(ch)) {
                scanner.close();
                throw new IllegalMapCharacterException(
                    "Illegal character '" + ch + "' in entry: \"" + line + "\"");
            }

            int row, col, level;
            try {
                row   = Integer.parseInt(tokens[1]);
                col   = Integer.parseInt(tokens[2]);
                level = Integer.parseInt(tokens[3]);
            } catch (NumberFormatException e) {
                scanner.close();
                throw new IncorrectMapFormatException(
                    "Expected integers for ROW COL LEVEL in: \"" + line + "\"");
            }

            if (level < 0 || level >= R || row < 0 || row >= M || col < 0 || col >= N) {
                scanner.close();
                throw new IncompleteMapException(
                    "Coordinate out of bounds in: \"" + line + "\". "
                    + "Valid: row 0-" + (M-1) + ", col 0-" + (N-1)
                    + ", maze 0-" + (R-1) + ".");
            }

            mazes[level][row][col] = ch;
        }

        scanner.close();
        return mazes;
    }

  
    private static File resolveFile(String filename) throws FileNotFoundException {
        // 1) Exact path
        File f = new File(filename);
        if (f.exists()) return f;

        // 2) Add .txt if not already there
        if (!filename.endsWith(".txt")) {
            f = new File(filename + ".txt");
            if (f.exists()) return f;
        }

        // 3) Look inside TEST/ subfolder
        f = new File("TEST" + File.separator + filename);
        if (f.exists()) return f;

        // 4) Look inside TEST/ subfolder with .txt
        if (!filename.endsWith(".txt")) {
            f = new File("TEST" + File.separator + filename + ".txt");
            if (f.exists()) return f;
        }

        // Nothing worked - throw with helpful message
        throw new FileNotFoundException(
            "Could not find file: \"" + filename + "\"\n" +
            "Tried:\n" +
            "  " + filename + "\n" +
            "  " + filename + ".txt\n" +
            "  TEST/" + filename + "\n" +
            "  TEST/" + filename + ".txt\n" +
            "Make sure the file is in your Eclipse project root folder,\n" +
            "or in a TEST/ subfolder inside it.");
    }

   
    private static String nextMeaningfulLine(Scanner scanner) {
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (!line.trim().isEmpty() && !line.trim().startsWith("//")) {
                return line;
            }
        }
        return null;
    }

    
    private static int[] readHeader(Scanner scanner, String filename)
            throws IncorrectMapFormatException {

        String headerLine = nextMeaningfulLine(scanner);

        if (headerLine == null) {
            throw new IncorrectMapFormatException(
                "File \"" + filename + "\" is empty or has no valid header. Expected: M N R");
        }

        headerLine = headerLine.trim();
        String[] parts = headerLine.split("\\s+");

        if (parts.length < 3) {
            throw new IncorrectMapFormatException(
                "First line must have three positive integers (M N R). "
                + "Found: \"" + headerLine + "\"");
        }

        int M, N, R;
        try {
            M = Integer.parseInt(parts[0]);
            N = Integer.parseInt(parts[1]);
            R = Integer.parseInt(parts[2]);
        } catch (NumberFormatException e) {
            throw new IncorrectMapFormatException(
                "First line must have three positive integers (M N R). "
                + "Non-integer found in: \"" + headerLine + "\"");
        }

        if (M <= 0 || N <= 0 || R <= 0) {
            throw new IncorrectMapFormatException(
                "M, N, and R must be positive non-zero integers. "
                + "Found: M=" + M + ", N=" + N + ", R=" + R);
        }

        return new int[]{M, N, R};
    }


    private static boolean isValidChar(char ch) {
        return ch == '.' || ch == '@' || ch == 'W' || ch == '$' || ch == '|';
    }
}